"""Check native MirrorOPD imports without starting Ray or allocating GPU tensors."""

import importlib
import importlib.metadata
import sys
import traceback
from pathlib import Path


def main():
    failures = []
    print("Python:", sys.executable, flush=True)
    print("Environment:", sys.prefix, flush=True)
    for name in (
        "verl", "torch", "vllm", "flash-attn", "TransferQueue",
        "liger-kernel", "transformers", "tensordict", "pytest",
    ):
        try:
            value = importlib.metadata.version(name)
            print(f"{name}: {value}", flush=True)
            expected = {"TransferQueue": "0.1.11", "liger-kernel": "0.8.4"}.get(name)
            if expected and value != expected:
                failures.append(f"{name}: expected {expected}, found {value}")
        except importlib.metadata.PackageNotFoundError:
            failures.append(f"{name}: package not installed")
            print(f"MISSING: {name}", flush=True)

    loaded = {}
    for name in (
        "torch", "verl", "vllm", "vllm._C_stable_libtorch",
        "vllm._custom_ops", "flash_attn", "transfer_queue", "liger_kernel",
    ):
        try:
            loaded[name] = importlib.import_module(name)
            print(f"OK: {name} ({getattr(loaded[name], '__file__', '')})", flush=True)
        except Exception:
            failures.append(f"import {name}")
            print(f"FAILED: {name}", flush=True)
            traceback.print_exc(file=sys.stdout)

    if "verl" in loaded:
        actual = Path(loaded["verl"].__file__).resolve()
        expected_root = Path(__file__).resolve().parent.parent
        if not actual.is_relative_to(expected_root / "verl"):
            failures.append(f"verl is not loaded from {expected_root / 'verl'}")

    if "transfer_queue" in loaded and not hasattr(loaded["transfer_queue"], "KVBatchMeta"):
        failures.append("transfer_queue.KVBatchMeta is missing")

    if "torch" in loaded:
        torch = loaded["torch"]
        print("CUDA runtime:", torch.version.cuda, flush=True)
        try:
            available = torch.cuda.is_available()
            print("GPU available:", available, flush=True)
            if not available:
                failures.append("torch.cuda.is_available() is False")
        except Exception:
            failures.append("GPU availability check")
            traceback.print_exc(file=sys.stdout)

    if failures:
        print("\nChecks that need attention:", flush=True)
        for failure in failures:
            print(" -", failure, flush=True)
        return 1
    print("\nImport checks passed. GPU kernels and training still need a runtime test.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
